const itemDatabase = require('./mhw-db/items.json');

const items = new Map();
const itemData = [];

for (const i of Object.keys(itemDatabase)) {
  items.set(i, itemDatabase[i]);
}

for(let [name, i] of items.entries()) {
  itemData.push(i.name);
}

module.exports = {
    retrieve: function(type, index) {
        let input = index.toLowerCase();
        if(type === 'item') {
          return pull(itemData, input, items);
        } else {
          return;
        }
    }
}

function pull(names, index, map) {
  const array = names.map(toLowerReplace);
  const dictionary = array.indexOf(index);
  const stringify = dictionary.toString();

  const info = map.get(stringify);

  let data = [];
  for(let key in info) {
    if(info.hasOwnProperty(key)) {
      let values = info[key];
      data.push(values);
    }
  }

  return data;
}

toUpper = function(x){
  return x.toUpperCase();
};

toLower = function(x) {
  return x.toLowerCase();
};

toLowerReplace = function(x) {
  return x.toLowerCase().replace(' ', '');
};
